-- GHEST.LUA & YUSUFCUM.CSS --
local QBCore = exports['qb-core']:GetCoreObject()
local frozen = false
local permissions = {
    ['kill'] = 'god',
    ['ban'] = 'admin',
    ['noclip'] = 'admin',
    ['kickall'] = 'admin',
    ['kick'] = 'admin',
}
local players = {}

QBCore.Functions.CreateCallback('test:getplayers', function(_, cb)
    cb(players)
end)

QBCore.Functions.CreateCallback('qb-admin:server:getrank', function(source, cb)
    if QBCore.Functions.HasPermission(source, 'god') or IsPlayerAceAllowed(source, 'command') then
        cb(true)
    else
        cb(false)
    end
end)


local function tablelength(table)
    local count = 0
    for _ in pairs(table) do
        count = count + 1
    end
    return count
end

-- GHESTLUA EKLENTİ REGİSTERNETEVETLER -- 

--## DV ALL KOMUTU İÇİN EVENT AMQ ##--
--#459 / 477 Satırlarıda aç.

-- RegisterServerEvent('qb-admin:server:deleteAllVehicles')
-- AddEventHandler('qb-admin:server:deleteAllVehicles', function()
--     local src = source
--     TriggerClientEvent('qb-admin:client:deleteAllVehicles', -1)
--     TriggerClientEvent('QBCore:Notify', src, 'Tüm sürücüsüz araclar temizlendi.', "primary")
-- end)



-- GHEST.LUA & YUSUFCUM.CSS --

-- DİSCORD WEBHOOK  --


RegisterNetEvent('qb-admin:server:GetPlayersForBlips', function()
    local src = source
    TriggerClientEvent('qb-admin:client:Show', src, players)
end)


-- ADMİN KİLL LOGU --

RegisterNetEvent('qb-admin:server:kill', function(player)
    TriggerClientEvent('hospital:client:KillPlayer', player.id)
    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Menüsünden Kill Kullanıldı",
            ["description"] = "Kullanan admin: **".. GetPlayerName(source) .."** \n Öldürülen Kişi **".. GetPlayerName(tonumber(player.id)) .."**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }

    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})

end)

-- ADMİN REVİVE LOGU --

RegisterNetEvent('qb-admin:server:revive', function(player)
    local Player = QBCore.Functions.GetPlayer(player.id)
    TriggerClientEvent('hospital:client:Revive', player.id)
    TriggerEvent('qb-log:server:CreateLog', 'admin', 'Admin Revledi ' .. QBCore.Functions.GetIdentifier(source, "discord"), 'green', 'Revlenen '.. Player.PlayerData.citizenid .. ' '..QBCore.Functions.GetIdentifier(player.id, "discord"))

    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Menüsünden Revive Kullanıldı",
            ["description"] = "Kullanan admin: **".. GetPlayerName(source) .."** \n Revlenen Kişi: **".. GetPlayerName(tonumber(player.id)) .."**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }

    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
end)

-- ADMİN KİCK LOGU --

RegisterNetEvent('qb-admin:server:kick', function(player, reason)
    local src = source
    if QBCore.Functions.HasPermission(src, permissions['kick']) or IsPlayerAceAllowed(src, 'command')  then
        local connect = {
            {
                ["color"] = "697551",
                ["title"] = "Admin Menüsünden Kickleme Kullanıldı",
                ["description"] = "Kullanan admin: **".. GetPlayerName(source) .."** \n Kicklenen Kişi **".. GetPlayerName(tonumber(player.id)) .."**\n Sebep :**".. reason .."**",
                ["footer"] = {
                    ["text"] = "GHESTLUA",
                    ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
                },
            }
        }
    
        PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    
        DropPlayer(player.id, Lang:t("info.kicked_server") .. ':\n' .. reason .. '\n\n' .. Lang:t("info.check_discord") .. QBCore.Config.Server.Discord)
    end
end)

-- ADMİN BAN LOGU --

RegisterNetEvent('qb-admin:server:ban', function(player, time, reason)
    local src = source
    if QBCore.Functions.HasPermission(src, permissions['ban']) or IsPlayerAceAllowed(src, 'command') then
        time = tonumber(time)
        local banTime = tonumber(os.time() + time)
        if banTime > 2147483647 then
            banTime = 2147483647
        end
        local timeTable = os.date('*t', banTime)
        MySQL.insert('INSERT INTO bans (name, license, discord, ip, reason, expire, bannedby) VALUES (?, ?, ?, ?, ?, ?, ?)', {
            GetPlayerName(player.id),
            QBCore.Functions.GetIdentifier(player.id, 'license'),
            QBCore.Functions.GetIdentifier(player.id, 'discord'),
            QBCore.Functions.GetIdentifier(player.id, 'ip'),
            reason,
            banTime,
            GetPlayerName(src)
        })
        TriggerClientEvent('chat:addMessage', -1, {
            template = "<div class=chat-message server'><strong>ANNOUNCEMENT | {0} has been banned:</strong> {1}</div>",
            args = {GetPlayerName(player.id), reason}
        })
        local connect = {
            {
                ["color"] = "697551",
                ["title"] = "Admin Menüsünden Banlama Kullanıldı",
                ["description"] = "Kullanan admin: **".. GetPlayerName(source) .."** \n Banlanan Kişi **".. GetPlayerName(tonumber(player.id)) .."**\n Sebep :**".. reason .."**",
                ["footer"] = {
                    ["text"] = "GHESTLUA",
                    ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
                },
            }
        }
    
        PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    
        if banTime >= 2147483647 then
            DropPlayer(player.id, Lang:t("info.banned") .. '\n' .. reason .. Lang:t("info.ban_perm") .. QBCore.Config.Server.Discord)
        else
            DropPlayer(player.id, Lang:t("info.banned") .. '\n' .. reason .. Lang:t("info.ban_expires") .. timeTable['day'] .. '/' .. timeTable['month'] .. '/' .. timeTable['year'] .. ' ' .. timeTable['hour'] .. ':' .. timeTable['min'] .. '\n🔸 Check our Discord for more information: ' .. QBCore.Config.Server.Discord)
        end
    end
end)

-- ADMİN İZLEME LOGU --

RegisterNetEvent('qb-admin:server:spectate', function(player)
    local src = source
    local targetped = GetPlayerPed(player.id)
    local coords = GetEntityCoords(targetped)
    TriggerClientEvent('qb-admin:client:spectate', src, player.id, coords)
    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Menüsünden Spectate Kullanıldı",
            ["description"] = "Kullanan admin: **".. GetPlayerName(source) .."** \n İzlenen Kişi **".. GetPlayerName(tonumber(player.id)) .."**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }

    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})

end)

-- ADMİN FREEZE LOGU --

RegisterNetEvent('qb-admin:server:freeze', function(player)
    local target = GetPlayerPed(player.id)
    if not frozen then
        frozen = true
        FreezeEntityPosition(target, true)
        local connect = {
            {
                ["color"] = "697551",
                ["title"] = "Admin Menüsünden Dondurma Kullanıldı",
                ["description"] = "Kullanan admin: **".. GetPlayerName(source) .."** \n Dondurulan Kişi **".. GetPlayerName(tonumber(player.id)) .."**",
                ["footer"] = {
                    ["text"] = "GHESTLUA",
                    ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
                },
            }
        }
    
        PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    
    else
        frozen = false
        FreezeEntityPosition(target, false)
        local connect = {
            {
                ["color"] = "697551",
                ["title"] = "Admin Menüsünden Dondurma Kaldırması Kullanıldı",
                ["description"] = "Kullanan admin: **".. GetPlayerName(source) .."** \n Dondurulan Kaldırıılan Kişi **".. GetPlayerName(tonumber(player.id)) .."**",
                ["footer"] = {
                    ["text"] = "GHESTLUA",
                    ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
                },
            }
        }
    
        PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})

    end
end)

-- ADMİN GOTO LOGU --

RegisterNetEvent('qb-admin:server:goto', function(player)
    local src = source
    local admin = GetPlayerPed(src)
    local coords = GetEntityCoords(GetPlayerPed(player.id))
    SetEntityCoords(admin, coords)
    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Menüsünden Goto Kullanıldı",
            ["description"] = "Kullanan admin: **".. GetPlayerName(source) .."** \n Gidilen Kişi **".. GetPlayerName(tonumber(player.id)) .."**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }

    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})

end)

-- ADMİN ARAÇ OTURT KULLAN --

RegisterNetEvent('qb-admin:server:intovehicle', function(player)
    local src = source
    local admin = GetPlayerPed(src)
    local targetPed = GetPlayerPed(player.id)
    local vehicle = GetVehiclePedIsIn(targetPed,false)
    local seat = -1
    if vehicle ~= 0 then
        for i=0,8,1 do
            if GetPedInVehicleSeat(vehicle,i) == 0 then
                seat = i
                break
            end
        end
        if seat ~= -1 then
            SetPedIntoVehicle(admin,vehicle,seat)
            local connect = {
                {
                    ["color"] = "697551",
                    ["title"] = "Admin Menüsünden Araç Oturt Kullanıldı",
                    ["description"] = "Kullanan admin: **".. GetPlayerName(source) .."** \n Oturtulan Kişi **".. GetPlayerName(tonumber(player.id)) .."**",
                    ["footer"] = {
                        ["text"] = "GHESTLUA",
                        ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
                    },
                }
            }
        
            PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
        
            TriggerClientEvent('QBCore:Notify', src, Lang:t("sucess.entered_vehicle"), 'success', 5000)
        else
            TriggerClientEvent('QBCore:Notify', src, Lang:t("error.no_free_seats"), 'danger', 5000)
        end
    end
end)

-- ## BUNU KAPADIM SİKTİR GİT ## --

-- RegisterNetEvent('qb-admin:server:bring', function(player)
--     local src = source
--     local admin = GetPlayerPed(src)
--     local coords = GetEntityCoords(admin)
--     local target = GetPlayerPed(player.id)
--     SetEntityCoords(target, coords)
--     local connect = {
--         {
--             ["color"] = "697551",
--             ["title"] = "Admin Menüsünden Bring Kullanıldı",
--             ["description"] = "Kullanan admin: **".. GetPlayerName(source) .."** \n Çekilen Kişi **".. GetPlayerName(tonumber(player.id)) .."**",
--             ["footer"] = {
--                 ["text"] = "GHESTLUA",
--                 ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
--             },
--         }
--     }

--     PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})

-- end)

-- ADMİN KARŞI TARAF ENVANTER AÇMA --

RegisterNetEvent('qb-admin:server:inventory', function(player)
    local src = source
    TriggerClientEvent('qb-admin:client:inventory', src, player.id)
    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Menüsünden Envanter Açma Kullanıldı",
            ["description"] = "Kullanan admin: **".. GetPlayerName(source) .."** \n Envanteri Açılan Kişi **".. GetPlayerName(tonumber(player.id)) .."**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }

    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})

end)

-- ADMİN KARAKTER MENÜSÜ LOGU --

RegisterNetEvent('qb-admin:server:cloth', function(player)
    TriggerClientEvent('qb-clothing:client:openMenu', player.id)
    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Menüsünden Karakter Menüsü Kullanıldı",
            ["description"] = "Kullanan admin: **".. GetPlayerName(source) .."** \n Karakter Menüsü Verilen Kişi **".. GetPlayerName(tonumber(player.id)) .."**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }

    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})

end)

-- ADMİN YETKİ VERME LOGU --

RegisterNetEvent('qb-admin:server:setPermissions', function(targetId, group)
    local src = source
    if QBCore.Functions.HasPermission(src, 'god') or IsPlayerAceAllowed(src, 'command') then
        QBCore.Functions.AddPermission(targetId, group[1].rank)
        TriggerClientEvent('QBCore:Notify', targetId, Lang:t("info.rank_level")..group[1].label)
        local connect = {
            {
                ["color"] = "697551",
                ["title"] = "Admin Menüsünden Yetki Verme Kullanıldı",
                ["description"] = "Kullanan admin: **".. GetPlayerName(source) .."** \n Yetki Verilen Kişi **".. GetPlayerName(targetId) .."** \n Verilen Yetki **"..group[1].rank.."**",
                ["footer"] = {
                    ["text"] = "GHESTLUA",
                    ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
                },
            }
        }
    
        PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    
    end
end)

RegisterNetEvent('qb-admin:server:SendReport', function(name, targetSrc, msg)
    local src = source
    if QBCore.Functions.HasPermission(src, 'admin') or IsPlayerAceAllowed(src, 'command') then
        if QBCore.Functions.IsOptin(src) then
            TriggerClientEvent('chat:addMessage', src, {
                color = {255, 0, 0},
                multiline = true,
                args = {Lang:t("info.admin_report")..name..' ('..targetSrc..')', msg}
            })
        end
    end
end)

RegisterNetEvent('qb-admin:server:Staffchat:addMessage', function(name, msg)
    local src = source
    if QBCore.Functions.HasPermission(src, 'admin') or IsPlayerAceAllowed(src, 'command') then
        if QBCore.Functions.IsOptin(src) then
            TriggerClientEvent('chat:addMessage', src, {
                color = {255, 0, 0},
                multiline = true,
                args = {Lang:t("info.staffchat")..name, msg}
            })
        end
    end
end)


RegisterServerEvent('qb-admin:giveWeapon', function(weapon)
    local src = source
    if QBCore.Functions.HasPermission(src, 'admin') or IsPlayerAceAllowed(src, 'command') then
        local Player = QBCore.Functions.GetPlayer(src)
        Player.Functions.AddItem(weapon, 1)
        TriggerEvent('qb-log:server:CreateLog', 'admin', 'Admin Silah Verdi  <@' .. QBCore.Functions.GetIdentifier(src, "discord") .. '>', 'green', 'Silah: '..weapon)
    end
end)

-- ADMİN KENDİ ÜSTÜNE ARAÇ BASMA LOGU --

RegisterNetEvent('qb-admin:server:SaveCar', function(mods, vehicle, _, plate)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local result = MySQL.query.await('SELECT plate FROM player_vehicles WHERE plate = ?', { plate })
    if result[1] == nil then
        MySQL.insert('INSERT INTO player_vehicles (license, citizenid, vehicle, hash, mods, plate, garage, stored) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', {
            Player.PlayerData.license,
            Player.PlayerData.citizenid,
            vehicle.model,
            vehicle.hash,
            json.encode(mods),
            plate,
            "A",
        })
        local connect = {
            {
                ["color"] = "697551",
                ["title"] = "Admin Menüsünden Kendi Datasına Araç Bastı",
                ["description"] = "Kullanan admin: **".. GetPlayerName(src) .."** \n Basılan Araç **".. vehicle.model .."**",
                ["footer"] = {
                    ["text"] = "GHESTLUA",
                    ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
                },
            }
        }
    
        PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})

        TriggerClientEvent('QBCore:Notify', src, Lang:t("success.success_vehicle_owner"), 'success', 5000)
    else
        TriggerClientEvent('QBCore:Notify', src, Lang:t("error.failed_vehicle_owner"), 'error', 3000)
    end
end)


-- KOMUTLAR GHESTLUA EKLEME OLANLAR AMQ --

--## ARAÇ ÇEKME BU AMQ ##--

-- QBCore.Commands.Add('dvall', "Sahipsiz araçları çeker", {}, false, function(source)
--     local src = source
--     local name = GetPlayerName(src)
--     TriggerEvent("qb-admin:server:deleteAllVehicles")
    
--     local connect = {
--         {
--             ["color"] = "697551",
--             ["title"] = "Admin Bütün Araçları Çekti",
--             ["description"] = "Kullanan admin: **".. name .."** \n Tüm araçlar çekildi.",
--             ["footer"] = {
--                 ["text"] = "GHESTLUA",
--                 ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
--             },
--         }
--     }
    
--     PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
-- end, 'admin')

-- KOMUTLAR GHESTLUA EKLEME OLANLAR AMQ --

--## OYUNCU ÇEKME AMQ ##--
QBCore.Commands.Add('bring', 'Bir oyuncuyu yanınıza çekin', {{name='id', help='Oyuncunun ID numarası'}}, true, function(source, args)
    local targetId = tonumber(args[1])
    if not targetId then
        TriggerClientEvent('QBCore:Notify', source, 'Geçerli bir oyuncu ID\'si girin', 'error')
        return
    end

    local srcName = GetPlayerName(source)
    local targetName = GetPlayerName(targetId)

    TriggerClientEvent('qb-adminmenu:client:bringPlayer', targetId, source)
    TriggerClientEvent('QBCore:Notify', source, 'ID '..targetId..' li kişiyi çektin', 'success')
    TriggerClientEvent('QBCore:Notify', targetId, 'Bir üst yetkili tarafından çekildiniz', 'inform')

    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Menüsünden Bring Kullanıldı",
            ["description"] = "Kullanan admin: **".. srcName .." (".. source ..")** \n Çekilen oyuncu: **".. targetName .." (".. targetId ..")**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }


    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
end, 'admin')

-- ARAÇ FULLEME LOGU --

QBCore.Commands.Add('maxmods', Lang:t("desc.max_mod_desc"), {}, false, function(source)
    local src = source
    TriggerClientEvent('qb-admin:client:maxmodVehicle', src)
    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Aracını Fulledi",
            ["description"] = "Kullanan admin: **".. GetPlayerName(src) .."** \n Komut: **/maxmods**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }

    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    
end, 'admin')

-- BLİP AÇMA LOGU --

QBCore.Commands.Add('blips', Lang:t("commands.blips_for_player"), {}, false, function(source)
    local src = source
    TriggerClientEvent('qb-admin:client:toggleBlips', src)
    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Blip'leri Açtı",
            ["description"] = "Kullanan admin: **".. GetPlayerName(src) .."** \n Komut: **/blips**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }

    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    
end, 'admin')

RegisterServerEvent('ghestluasal', function()
    local src = source
    TriggerClientEvent('qb-admin:client:toggleNames', src)
end)

-- İSİM AÇMA LOGU -- 

QBCore.Commands.Add('names', Lang:t("commands.player_name_overhead"), {}, false, function(source)
    local src = source
    TriggerClientEvent('qb-admin:client:toggleNames', src)
    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin İsim'leri Açtı",
            ["description"] = "Kullanan admin: **".. GetPlayerName(src) .."** \n Komut: **/names**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }

    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    
end, 'admin')

-- KORDİNAT AÇMA KAPAMA LOGU --

local coordsStatus = {}

QBCore.Commands.Add('coords', Lang:t("commands.coords_dev_command"), {}, false, function(source)
    local src = source
    local playerName = GetPlayerName(src)

    if coordsStatus[src] == nil then
        coordsStatus[src] = false
    end

    coordsStatus[src] = not coordsStatus[src]

    if coordsStatus[src] then
        TriggerClientEvent('qb-admin:client:ToggleCoords', src, true)
        local connect = {
            {
                ["color"] = "697551",
                ["title"] = "Admin Kordinat'ları Açtı",
                ["description"] = "Kullanan admin: **" .. playerName .. "** \n Komut: **/coords**",
                ["footer"] = {
                    ["text"] = "GHESTLUA",
                    ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
                },
            }
        }
        PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    else
        TriggerClientEvent('qb-admin:client:ToggleCoords', src, false)
        local connect = {
            {
                ["color"] = "16711680",
                ["title"] = "Admin Kordinat'ları Kapattı",
                ["description"] = "Kullanan admin: **" .. playerName .. "** \n Komut: **/coords**",
                ["footer"] = {
                    ["text"] = "GHESTLUA",
                    ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
                },
            }
        }
        PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    end
end, 'admin')



-- NOCLİP LOGU --

local noClipStatus = {}

QBCore.Commands.Add('noclip', Lang:t("commands.toogle_noclip"), {}, false, function(source)
    local src = source
    local playerName = GetPlayerName(src)

    if noClipStatus[src] == nil then
        noClipStatus[src] = false
    end

    noClipStatus[src] = not noClipStatus[src]

    if noClipStatus[src] then
        TriggerClientEvent('qb-admin:client:ToggleNoClip', src)
        local connect = {
            {
                ["color"] = "697551",
                ["title"] = "Admin Noclip Açtı",
                ["description"] = "Kullanan admin: **".. playerName .."** \n Komut: **/noclip**",
                ["footer"] = {
                    ["text"] = "GHESTLUA",
                    ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
                },
            }
        }
        PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    else
        TriggerClientEvent('qb-admin:client:ToggleNoClip', src)
        local connect = {
            {
                ["color"] = "16711680",
                ["title"] = "Admin Noclip Kapattı",
                ["description"] = "Kullanan admin: **".. playerName .."** \n Komut: **/noclip**",
                ["footer"] = {
                    ["text"] = "GHESTLUA",
                    ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
                },
            }
        }
        PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    end
end, 'admin')


QBCore.Commands.Add('admincar', Lang:t("commands.save_vehicle_garage"), {}, false, function(source, _)
    TriggerClientEvent('qb-admin:client:SaveCar', source)
end, 'admin')

QBCore.Commands.Add('announce', Lang:t("commands.make_announcement"), {}, false, function(_, args)
    local msg = table.concat(args, ' ')
    if msg == '' then return end
    TriggerClientEvent('chat:addMessage', -1, {
        color = { 255, 0, 0},
        multiline = true,
        args = {"Announcement", msg}
    })
end, 'admin')

-- ADMİN MENÜSÜNÜ AÇMA LOGU --

QBCore.Commands.Add('admin', Lang:t("commands.open_admin"), {}, false, function(source, _)
    local src = source
    TriggerClientEvent('qb-admin:client:openMenu', src)
    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Menü Açtı",
            ["description"] = "Kullanan admin: **".. GetPlayerName(src) .."** \n Komut: **/admin**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }

    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    
end, 'admin')


local reportCooldown = {} -- #Report cooldown tutacak bura amınısikim#

QBCore.Commands.Add('report', Lang:t("info.admin_report"), {{name='message', help='Message'}}, true, function(source, args)
    local src = source
    local msg = table.concat(args, ' ')
    local Player = QBCore.Functions.GetPlayer(src)

    -- Cooldown kontrol eğer bitti ise 
    if reportCooldown[src] and reportCooldown[src] > os.time() then
        local remainingTime = reportCooldown[src] - os.time()
        TriggerClientEvent("QBCore:Notify", src, "Şikayet komutunu tekrar kullanmak için " .. remainingTime .. " saniye beklemeniz gerekiyor.", "error")
        return
    end

    -- Şikayet gönderme işlemi
    TriggerClientEvent('qb-admin:client:SendReport', -1, GetPlayerName(src), src, msg)
    TriggerClientEvent("QBCore:Notify", src, "Şikayetiniz gönderildi, en kısa sürede geri dönüş yapılacaktır!", "success")
    TriggerEvent('qbcore-log:server:CreateLog', 'report', 'Report', 'green', '**'..GetPlayerName(source)..'** (CitizenID: '..Player.PlayerData.citizenid..' | ID: '..src..') **Report:** ' ..msg, false)

    -- Cooldown 5 saniye
    reportCooldown[src] = os.time() + 5
end)

QBCore.Commands.Add('reporttoggle', Lang:t("commands.report_toggle"), {}, false, function(source, _)
    local src = source
    QBCore.Functions.ToggleOptin(src)
    if QBCore.Functions.IsOptin(src) then
        TriggerClientEvent('QBCore:Notify', src, Lang:t("success.receive_reports"), 'success')
    else
        TriggerClientEvent('QBCore:Notify', src, Lang:t("error.no_receive_report"), 'error')
    end
end, 'admin')

QBCore.Commands.Add('kickall', Lang:t("commands.kick_all"), {}, false, function(source, args)
    local src = source
    if src > 0 then
        local reason = table.concat(args, ' ')
        if QBCore.Functions.HasPermission(src, 'god') or IsPlayerAceAllowed(src, 'command') then
            if reason and reason ~= '' then
                for _, v in pairs(QBCore.Functions.GetPlayers()) do
                    local Player = QBCore.Functions.GetPlayer(v)
                    if Player then
                        DropPlayer(Player.PlayerData.source, reason)
                    end
                end
            else
                TriggerClientEvent('QBCore:Notify', src, Lang:t("info.no_reason_specified"), 'error')
            end
        end
    else
        for _, v in pairs(QBCore.Functions.GetPlayers()) do
            local Player = QBCore.Functions.GetPlayer(v)
            if Player then
                DropPlayer(Player.PlayerData.source, Lang:t("info.server_restart") .. QBCore.Config.Server.Discord)
            end
        end
    end
end, 'god')

-- MERMİ VERME LOGU --

QBCore.Commands.Add('setammo', Lang:t("commands.ammo_amount_set"), {
    {name='amount', help='Mermi miktarı, örneğin: 20'},
    {name='weapon', help='Silahın adı, örneğin: WEAPON_VINTAGEPISTOL'}
}, false, function(source, args)
    local src = source
    local weapon = args[2] or 'current'
    local amount = tonumber(args[1])

    if weapon and weapon ~= '' then
        TriggerClientEvent('qb-weapons:client:SetWeaponAmmoManual', src, weapon, amount)
    else
        weapon = 'current'
        TriggerClientEvent('qb-weapons:client:SetWeaponAmmoManual', src, weapon, amount)
    end
    
    local connection = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Mermi Bastı",
            ["description"] = "Kullanan admin: **" .. GetPlayerName(src) .. "** \n Mermi Sayısı: **" .. amount .. "**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png"
            }
        }
    }
    PerformHttpRequest("WEBHOOK GİR DOSTUMS", 
    function(err, text, headers)
    end, 
    'POST', 
    json.encode({username = "GHESTLUA", embeds = connection}), 
    {['Content-Type'] = 'application/json'})
end, 'admin')



-- VECTOR2 KOPYALAMA LOGU --

QBCore.Commands.Add('vector2', 'Vector2 Kordinatını Kopyala (Admin Only)', {}, false, function(source)
    local src = source
    TriggerClientEvent('qb-admin:client:copyToClipboard', src, 'coords2')
    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Vector2 Kopyaladı",
            ["description"] = "Kullanan admin: **".. GetPlayerName(src) .."** \n Komut: **/vector2**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }

    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    
end, 'admin')

-- VECTOR3 KOPYALAMA LOGU --

QBCore.Commands.Add('vector3', 'Vector3 Kordinatını Kopyala (Admin Only)', {}, false, function(source)
    local src = source
    TriggerClientEvent('qb-admin:client:copyToClipboard', src, 'coords3')
    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Vector3 Kopyaladı",
            ["description"] = "Kullanan admin: **".. GetPlayerName(src) .."** \n Komut: **/vector3**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }

    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    
end, 'admin')

-- VECTOR4 KOPYALAMA LOGU --

QBCore.Commands.Add('vector4', 'Vector4 Kordinatını Kopyala (Admin Only)', {}, false, function(source)
    local src = source
    TriggerClientEvent('qb-admin:client:copyToClipboard', src, 'coords4')
    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Vector4 Kopyaladı",
            ["description"] = "Kullanan admin: **".. GetPlayerName(src) .."** \n Komut: **/vector4**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }

    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    
end, 'admin')

-- HEADİNG KOPYALAMA LOGU --

QBCore.Commands.Add('heading', 'Bakış Açısı Kopyala (Admin only)', {}, false, function(source)
    local src = source
    TriggerClientEvent('qb-admin:client:copyToClipboard', src, 'heading')
    local connect = {
        {
            ["color"] = "697551",
            ["title"] = "Admin Bakış Açısı Kopyaladı",
            ["description"] = "Kullanan admin: **".. GetPlayerName(src) .."** \n Komut: **/heading**",
            ["footer"] = {
                ["text"] = "GHESTLUA",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png",
            },
        }
    }

    PerformHttpRequest("WEBHOOK GİR DOSTUMS", function(err, text, headers) end, 'POST', json.encode({username = "GHESTLUA", embeds = connect}), {['Content-Type'] = 'application/json'})
    
end, 'admin')

CreateThread(function()
    while true do
        local tempPlayers = {}
        for _, v in pairs(QBCore.Functions.GetPlayers()) do
            local targetped = GetPlayerPed(v)
            local ped = QBCore.Functions.GetPlayer(v)
            tempPlayers[#tempPlayers + 1] = {
                name = (ped.PlayerData.charinfo.firstname or '') .. ' ' .. (ped.PlayerData.charinfo.lastname or '') .. ' | (' .. (GetPlayerName(v) or '') .. ')',
                id = v,
                coords = GetEntityCoords(targetped),
                cid = ped.PlayerData.charinfo.firstname .. ' ' .. ped.PlayerData.charinfo.lastname,
                citizenid = ped.PlayerData.citizenid,
                sources = GetPlayerPed(ped.PlayerData.source),
                sourceplayer = ped.PlayerData.source

            }
        end
        table.sort(tempPlayers, function(a, b)
            return a.id < b.id
        end)
        players = tempPlayers
        Wait(1500)
    end
end)


-- ÇİFT KARAKTER GİRİŞ DUPE ENGELLEME -- 
playerstable = {}

Config = {
    DiscordLog = true,
    Kick = true,
    Low_Player_Limit = 2,
    WebhookColor = 16776960,
    Webhook = "WEBHOOK GİR DOSTUMS"
}

Citizen.CreateThread(function()
    while true do
        if (#GetPlayers() >= Config.Low_Player_Limit) then
            for k,v in pairs(GetPlayers()) do
                Citizen.Wait(100)
                if not GetPlayerName(v) then return end
                local endpoint = GetPlayerEndpoint(v)
                
                if playerstable[endpoint] == 1 then
                    if Config.DiscordLog then
                    DiscordLog('**• Hex:** '..GetPlayerIdentifier(v, 0)..'\n **• Steam Adı:** '..GetPlayerName(v).."\n**• Id:** "..v)
                    end
                    if Config.Kick then
                    DropPlayer(v, Config.Kick_Message)
                    end
                end
                playerstable[endpoint] = 0
                if playerstable[endpoint] then
                    playerstable[endpoint] = playerstable[endpoint] + 1
                end
            end
            playerstable = {}
        end
        Citizen.Wait(10000)
    end
end)

DiscordLog = function(message)
    local embed = {
        {  
            ["author"] = {
            ["name"] = "DOUBLE DUPER ENGELLENDİ",
        },
            ["color"] = Config.WebhookColor, 
            ["title"] = "",
            ["description"] = message,
            ["footer"] = {
                ["text"] = "SİKTİM ÖLDÜ OROSPU EVLADI",
                ["icon_url"] = "https://i.ibb.co/zGjvvRw/ZDev-Banner-Tasarm.png"
            },
        }
    }
    PerformHttpRequest(Config.Webhook, function(err, text, headers) end, 'POST', json.encode({username = name, embeds = embed}), { ['Content-Type'] = 'application/json' })
end

-- GHEST.LUA & YUSUFCUM.CSS --